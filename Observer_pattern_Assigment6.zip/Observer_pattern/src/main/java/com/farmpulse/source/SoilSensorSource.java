package com.farmpulse.source;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.EventBusSubject;

import java.time.Instant;
import java.util.Map;

public class SoilSensorSource extends EventBusSubject<FarmEvent> {

    private final String sensorId;

    public SoilSensorSource(String sensorId) {
        this.sensorId = sensorId;
    }

    public void publishMoisture(double moisture, String fieldId) {
        publish(new FarmEvent(
                EventType.SOIL_MOISTURE_READING,
                sensorId,
                Instant.now(),
                Map.of("moisture", moisture, "fieldId", fieldId)
        ));
    }
}