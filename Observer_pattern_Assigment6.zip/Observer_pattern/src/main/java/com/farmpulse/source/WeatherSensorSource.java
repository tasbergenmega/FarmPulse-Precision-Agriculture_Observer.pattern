package com.farmpulse.source;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.EventBusSubject;

import java.time.Instant;
import java.util.Map;

public class WeatherSensorSource extends EventBusSubject<FarmEvent> {

    private final String stationId;

    public WeatherSensorSource(String stationId) {
        this.stationId = stationId;
    }

    public void publishTemperature(double celsius, String fieldId) {
        publish(new FarmEvent(
                EventType.TEMPERATURE_READING,
                stationId,
                Instant.now(),
                Map.of("celsius", celsius, "fieldId", fieldId)
        ));
    }

    public void publishFrostWarning(String fieldId) {
        publish(new FarmEvent(
                EventType.FROST_WARNING,
                stationId,
                Instant.now(),
                Map.of("fieldId", fieldId)
        ));
    }
}