package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public final class Crop implements FarmElement {
    private final String name;
    private final double waterPerDayLiters;
    private final double expectedYieldKg;

    public Crop(String name, double waterPerDayLiters, double expectedYieldKg) {
        this.name = name;
        this.waterPerDayLiters = waterPerDayLiters;
        this.expectedYieldKg = expectedYieldKg;
    }

    public String name() { return name; }
    public double waterPerDayLiters() { return waterPerDayLiters; }
    public double expectedYieldKg() { return expectedYieldKg; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}