package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public final class Sensor implements FarmElement {
    private final String id;
    private final double currentMoisturePercent;

    public Sensor(String id, double currentMoisturePercent) {
        this.id = id;
        this.currentMoisturePercent = currentMoisturePercent;
    }

    public String id() { return id; }
    public double currentMoisturePercent() { return currentMoisturePercent; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}