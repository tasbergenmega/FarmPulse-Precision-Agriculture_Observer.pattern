package com.farmpulse.tree;

import java.util.List;

public interface CompositeElement extends FarmElement {
    List<FarmElement> children();
}