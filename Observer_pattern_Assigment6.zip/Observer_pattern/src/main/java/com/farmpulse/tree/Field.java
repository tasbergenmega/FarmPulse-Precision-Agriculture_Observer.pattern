package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;
import java.util.List;

public final class Field implements CompositeElement {
    private final String id;
    private final String name;
    private final double areaHectares;
    private final List<FarmElement> elements;

    public Field(String id, String name, double areaHectares, List<FarmElement> elements) {
        this.id = id;
        this.name = name;
        this.areaHectares = areaHectares;
        this.elements = List.copyOf(elements);
    }

    public String id() { return id; }
    public String name() { return name; }
    public double areaHectares() { return areaHectares; }
    @Override public List<FarmElement> children() { return elements; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}