package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public final class WeatherStation implements FarmElement {
    private final String id;

    public WeatherStation(String id) {
        this.id = id;
    }

    public String id() { return id; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}