package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;
import java.util.List;

public final class Farm implements CompositeElement {
    private final String id;
    private final String name;
    private final List<FarmElement> fields;

    public Farm(String id, String name, List<FarmElement> fields) {
        this.id = id;
        this.name = name;
        this.fields = List.copyOf(fields);
    }

    public String id() { return id; }
    public String name() { return name; }
    @Override public List<FarmElement> children() { return fields; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}