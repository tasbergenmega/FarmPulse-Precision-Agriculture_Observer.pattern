package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public final class Pump implements FarmElement {
    private final String id;
    private final double flowRateLitersPerHour;

    public Pump(String id, double flowRateLitersPerHour) {
        this.id = id;
        this.flowRateLitersPerHour = flowRateLitersPerHour;
    }

    public String id() { return id; }
    public double flowRateLitersPerHour() { return flowRateLitersPerHour; }
    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}