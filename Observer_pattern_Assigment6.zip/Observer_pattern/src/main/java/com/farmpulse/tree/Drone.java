package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public final class Drone implements FarmElement {
    private final String id;
    private final double batteryLevel;

    public Drone(String id, double batteryLevel) {
        this.id = id;
        this.batteryLevel = batteryLevel;
    }

    public String id() { return id; }
    public double batteryLevel() { return batteryLevel; }

    @Override public <R> R accept(Visitor<R> visitor) { return visitor.visit(this); }
}