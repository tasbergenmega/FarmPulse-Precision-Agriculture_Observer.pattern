package com.farmpulse.tree;

import com.farmpulse.visitor.Visitor;

public interface FarmElement {
    <R> R accept(Visitor<R> visitor);
}