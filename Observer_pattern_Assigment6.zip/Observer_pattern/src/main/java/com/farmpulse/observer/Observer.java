package com.farmpulse.observer;

public interface Observer<E> {
    void onEvent(E event);
}