package com.farmpulse.observer;

import com.farmpulse.event.Event;
import com.farmpulse.event.EventType;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBusSubject<E extends Event> implements Subject<E> {

    // ConcurrentHashMap позволяет разным потокам подписываться одновременно
    // CopyOnWriteArrayList позволяет безопасно отписываться прямо во время рассылки
    private final Map<EventType, CopyOnWriteArrayList<Observer<E>>> listeners = new ConcurrentHashMap<>();

    @Override
    public void subscribe(EventType type, Observer<E> observer) {
        if (type == null || observer == null) {
            throw new IllegalArgumentException("type and observer are required");
        }
        listeners.computeIfAbsent(type, t -> new CopyOnWriteArrayList<>()).add(observer);
    }

    @Override
    public void unsubscribe(EventType type, Observer<E> observer) {
        if (type == null || observer == null) return;
        CopyOnWriteArrayList<Observer<E>> list = listeners.get(type);
        if (list != null) {
            list.remove(observer);
        }
    }

    @Override
    public void publish(E event) {
        if (event == null) throw new IllegalArgumentException("event is required");
        CopyOnWriteArrayList<Observer<E>> list = listeners.get(event.getType());
        if (list == null) return;

        // Итерация идет по снимку (snapshot) списка, поэтому
        // если кто-то отпишется внутри onEvent, ошибки не будет
        for (Observer<E> observer : list) {
            observer.onEvent(event);
        }
    }
}