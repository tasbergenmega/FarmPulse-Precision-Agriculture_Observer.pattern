package com.farmpulse.listener;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.Observer;
import com.farmpulse.observer.Subject;
import com.farmpulse.repository.FarmRepository;
import com.farmpulse.tree.Field;
import com.farmpulse.visitor.HarvestEstimateVisitor;

import java.time.Instant;
import java.util.Map;

public class FrostAlertListener implements Observer<FarmEvent> {

    private final FarmRepository repository;
    private final Subject<FarmEvent> eventBus;

    public FrostAlertListener(FarmRepository repository, Subject<FarmEvent> eventBus) {
        this.repository = repository;
        this.eventBus = eventBus;
    }

    @Override
    public void onEvent(FarmEvent event) {
        if (event.type() != EventType.FROST_WARNING) return;

        String fieldId = (String) event.payload().get("fieldId");
        Field field = repository.findField(fieldId)
                .orElseThrow(() -> new IllegalArgumentException("Поле не найдено: " + fieldId));

        // ИНТЕГРАЦИЯ: Запускаем Visitor ТОЛЬКО на этом конкретном поле
        double estimate = field.accept(new HarvestEstimateVisitor());

        // Отправляем результат обратно в систему
        eventBus.publish(new FarmEvent(
                EventType.HARVEST_ESTIMATE_REPORT,
                "frost-alert",
                Instant.now(),
                Map.of("fieldId", fieldId, "estimateKg", estimate)
        ));
    }
}