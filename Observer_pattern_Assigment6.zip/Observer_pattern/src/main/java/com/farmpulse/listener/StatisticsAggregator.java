package com.farmpulse.listener;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.EventBusSubject;
import com.farmpulse.observer.Observer;
import com.farmpulse.observer.Subject;

import java.time.Instant;
import java.util.Map;

public class StatisticsAggregator implements Observer<FarmEvent>, Subject<FarmEvent> {

    private final Subject<FarmEvent> delegate = new EventBusSubject<>();
    private int moistureReadings = 0;
    private double moistureSum = 0;
    private int frostWarnings = 0;

    @Override
    public void onEvent(FarmEvent event) {
        switch (event.type()) {
            case SOIL_MOISTURE_READING -> {
                moistureReadings++;
                moistureSum += (double) event.payload().get("moisture");
            }
            case FROST_WARNING -> frostWarnings++;
            default -> { return; } // Игнорируем другие события
        }

        // Публикуем обновленную статистику
        double avg = moistureReadings == 0 ? 0 : moistureSum / moistureReadings;
        delegate.publish(new FarmEvent(
                EventType.AGGREGATED_STATISTICS,
                "statistics-aggregator",
                Instant.now(),
                Map.of("avgMoisture", avg, "frostWarnings", frostWarnings)
        ));
    }

    @Override public void subscribe(EventType type, Observer<FarmEvent> observer) { delegate.subscribe(type, observer); }
    @Override public void unsubscribe(EventType type, Observer<FarmEvent> observer) { delegate.unsubscribe(type, observer); }
    @Override public void publish(FarmEvent event) { delegate.publish(event); }
}