package com.farmpulse.listener;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.Observer;
import com.farmpulse.observer.Subject;

import java.time.Instant;
import java.util.Map;

public class IrrigationController implements Observer<FarmEvent> {

    private final Subject<FarmEvent> eventBus;
    private final double threshold;

    public IrrigationController(Subject<FarmEvent> eventBus, double threshold) {
        this.eventBus = eventBus;
        this.threshold = threshold;
    }

    @Override
    public void onEvent(FarmEvent event) {
        if (event.type() != EventType.SOIL_MOISTURE_READING) return;

        double moisture = (double) event.payload().get("moisture");
        if (moisture < threshold) {
            // Если влажность ниже порога, генерируем новое событие "Нужен полив"
            eventBus.publish(new FarmEvent(
                    EventType.IRRIGATION_NEEDED,
                    "irrigation-controller",
                    Instant.now(),
                    Map.of("fieldId", event.payload().get("fieldId"), "moisture", moisture)
            ));
        }
    }
}