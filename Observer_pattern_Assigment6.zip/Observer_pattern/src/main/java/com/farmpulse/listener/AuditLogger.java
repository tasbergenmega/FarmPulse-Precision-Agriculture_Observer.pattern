package com.farmpulse.listener;

import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.Observer;
import java.util.concurrent.atomic.AtomicInteger;

public class AuditLogger implements Observer<FarmEvent> {
    private final AtomicInteger count = new AtomicInteger();

    @Override
    public void onEvent(FarmEvent event) {
        count.incrementAndGet();
    }

    public int getCount() {
        return count.get();
    }
}