package com.farmpulse.listener;

import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.Observer;

public class FarmerAppNotifier implements Observer<FarmEvent> {
    @Override
    public void onEvent(FarmEvent event) {
        System.out.println("[Приложение фермера] Пуш-уведомление: " + event.type());
    }
}