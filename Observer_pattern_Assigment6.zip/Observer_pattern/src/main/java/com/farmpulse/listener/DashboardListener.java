package com.farmpulse.listener;

import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.Observer;

public class DashboardListener implements Observer<FarmEvent> {
    @Override
    public void onEvent(FarmEvent event) {
        System.out.println("[Дашборд] Получено: " + event.type() + " | Данные: " + event.payload());
    }
}