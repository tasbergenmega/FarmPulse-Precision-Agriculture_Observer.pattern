package com.farmpulse.simulation;

import com.farmpulse.source.SoilSensorSource;
import com.farmpulse.source.WeatherSensorSource;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class FarmSimulation {
    private final ExecutorService executor;
    private final SoilSensorSource soil;
    private final WeatherSensorSource weather;

    public FarmSimulation(int threadCount, SoilSensorSource soil, WeatherSensorSource weather) {
        // Создаем пул потоков заданного размера
        this.executor = Executors.newFixedThreadPool(threadCount);
        this.soil = soil;
        this.weather = weather;
    }

    public void run(int eventsPerProducer) {
        // Поток 1: Генерирует влажность почвы
        executor.submit(() -> {
            for (int i = 0; i < eventsPerProducer; i++) {
                soil.publishMoisture(20 + (i % 40), "f1");
            }
        });

        // Поток 2: Генерирует температуру и иногда мороз
        executor.submit(() -> {
            for (int i = 0; i < eventsPerProducer; i++) {
                weather.publishTemperature(10 + (i % 15), "f1");
                if (i % 10 == 0) {
                    weather.publishFrostWarning("f1");
                }
            }
        });

        // Поток 3: Еще один датчик влажности (для нагрузки)
        executor.submit(() -> {
            for (int i = 0; i < eventsPerProducer; i++) {
                soil.publishMoisture(50 + (i % 10), "f1");
            }
        });
    }

    public void shutdown() throws InterruptedException {
        // Мягкая остановка потоков без потери событий
        executor.shutdown();
        if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
            executor.shutdownNow();
        }
    }
}