package com.farmpulse.repository;

import com.farmpulse.tree.Field;
import com.farmpulse.tree.FarmElement;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class FarmRepository {
    private final Map<String, Field> fieldsById = new HashMap<>();

    public void registerTree(com.farmpulse.tree.Farm farm) {
        for (FarmElement element : farm.children()) {
            if (element instanceof Field f) {
                fieldsById.put(f.id(), f);
            }
        }
    }

    public Optional<Field> findField(String id) {
        return Optional.ofNullable(fieldsById.get(id));
    }
}