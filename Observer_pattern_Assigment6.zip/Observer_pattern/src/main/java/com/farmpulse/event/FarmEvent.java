package com.farmpulse.event;

import java.time.Instant;
import java.util.Map;

public record FarmEvent(
        EventType type,
        String sourceId,
        Instant timestamp,
        Map<String, Object> payload
) implements Event {

    public FarmEvent {
        if (type == null) throw new IllegalArgumentException("type is required");
        if (sourceId == null) throw new IllegalArgumentException("sourceId is required");
        if (timestamp == null) throw new IllegalArgumentException("timestamp is required");
        payload = payload == null ? Map.of() : Map.copyOf(payload);
    }

    @Override
    public EventType getType() {
        return type;
    }
}