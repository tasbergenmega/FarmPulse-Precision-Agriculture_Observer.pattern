package com.farmpulse.event;

public interface Event {
    EventType getType();
}