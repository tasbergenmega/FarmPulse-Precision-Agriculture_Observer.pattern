package com.farmpulse.app;

import com.farmpulse.event.EventType;
import com.farmpulse.listener.*;
import com.farmpulse.repository.FarmRepository;
import com.farmpulse.simulation.FarmSimulation;
import com.farmpulse.source.SoilSensorSource;
import com.farmpulse.source.WeatherSensorSource;
import com.farmpulse.tree.*;
import com.farmpulse.visitor.JsonExportVisitor;

import java.util.List;

public class FarmApplication {
    public static void main(String[] args) throws Exception {
        // 1. Строим дерево (Ферма -> Поле -> Элементы)
        Crop wheat = new Crop("Wheat", 10.0, 500.0);
        Pump pump = new Pump("P1", 100.0);
        Sensor sensor = new Sensor("S1", 25.0);
        WeatherStation station = new WeatherStation("WS1");

        Field northField = new Field("f1", "North Field", 10.0, List.of(wheat, pump, sensor, station));
        Farm farm = new Farm("farm1", "Main Farm", List.of(northField));

        FarmRepository repo = new FarmRepository();
        repo.registerTree(farm);

        // 2. Создаем источники (Subjects)
        SoilSensorSource soilSource = new SoilSensorSource("soil-1");
        WeatherSensorSource weatherSource = new WeatherSensorSource("weather-1");

        // 3. Создаем слушателей (Listeners)
        DashboardListener dashboard = new DashboardListener();
        FarmerAppNotifier notifier = new FarmerAppNotifier();
        AuditLogger auditLogger = new AuditLogger();
        IrrigationController irrigation = new IrrigationController(soilSource, 35.0);
        FrostAlertListener frostAlert = new FrostAlertListener(repo, weatherSource);
        StatisticsAggregator aggregator = new StatisticsAggregator();

        // 4. Подписываем слушателей на события
        soilSource.subscribe(EventType.SOIL_MOISTURE_READING, dashboard);
        soilSource.subscribe(EventType.SOIL_MOISTURE_READING, auditLogger);
        soilSource.subscribe(EventType.SOIL_MOISTURE_READING, irrigation);
        soilSource.subscribe(EventType.SOIL_MOISTURE_READING, aggregator);

        weatherSource.subscribe(EventType.FROST_WARNING, frostAlert);
        weatherSource.subscribe(EventType.FROST_WARNING, notifier);
        weatherSource.subscribe(EventType.FROST_WARNING, aggregator);

        // Подписываем дашборд на агрегированную статистику (цепочка)
        aggregator.subscribe(EventType.AGGREGATED_STATISTICS, dashboard);

        // 5. Запускаем симуляцию (4 потока, по 10 событий на каждый)
        System.out.println("=== ЗАПУСК СИМУЛЯЦИИ ===");
        FarmSimulation simulation = new FarmSimulation(4, soilSource, weatherSource);
        simulation.run(10);
        simulation.shutdown();

        System.out.println("\n=== СИМУЛЯЦИЯ ЗАВЕРШЕНА ===");
        System.out.println("Всего событий прошло через аудит: " + auditLogger.getCount());

        // 6. Проверяем Visitor (JSON экспорт)
        System.out.println("\n=== JSON ЭКСПОРТ ДЕРЕВА ===");
        System.out.println(farm.accept(new JsonExportVisitor()));
    }
}