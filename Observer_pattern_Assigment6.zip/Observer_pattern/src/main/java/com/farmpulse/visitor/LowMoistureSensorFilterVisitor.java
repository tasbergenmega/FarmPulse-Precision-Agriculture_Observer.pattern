package com.farmpulse.visitor;

import com.farmpulse.tree.*;
import java.util.ArrayList;
import java.util.List;

public final class LowMoistureSensorFilterVisitor implements Visitor<List<Sensor>> {

    private final double thresholdPercent;

    public LowMoistureSensorFilterVisitor(double thresholdPercent) {
        this.thresholdPercent = thresholdPercent;
    }

    @Override public List<Sensor> visit(Farm farm) { return collect(farm); }
    @Override public List<Sensor> visit(Field field) { return collect(field); }

    @Override public List<Sensor> visit(Crop crop) { return List.of(); }
    @Override public List<Sensor> visit(Pump pump) { return List.of(); }
    @Override public List<Sensor> visit(WeatherStation station) { return List.of(); }
    @Override public List<Sensor> visit(Drone drone) { return List.of(); }

    @Override public List<Sensor> visit(Sensor sensor) {
        return sensor.currentMoisturePercent() < thresholdPercent ? List.of(sensor) : List.of();
    }

    private List<Sensor> collect(CompositeElement element) {
        List<Sensor> result = new ArrayList<>();
        for (FarmElement child : element.children()) {
            result.addAll(child.accept(this));
        }
        return result;
    }
}