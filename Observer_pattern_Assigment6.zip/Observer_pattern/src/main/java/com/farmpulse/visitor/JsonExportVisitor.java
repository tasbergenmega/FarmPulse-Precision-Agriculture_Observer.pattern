package com.farmpulse.visitor;

import com.farmpulse.tree.*;

public final class JsonExportVisitor implements Visitor<String> {

    @Override public String visit(Farm farm) {
        return "{\"farm\":\"" + farm.name() + "\",\"fields\":[" + join(farm.children()) + "]}";
    }

    @Override public String visit(Field field) {
        return "{\"field\":\"" + field.name() + "\",\"elements\":[" + join(field.children()) + "]}";
    }

    @Override public String visit(Crop crop) {
        return "{\"type\":\"crop\",\"name\":\"" + crop.name() + "\"}";
    }
    @Override public String visit(Pump pump) {
        return "{\"type\":\"pump\",\"id\":\"" + pump.id() + "\"}";
    }
    @Override public String visit(Sensor sensor) {
        return "{\"type\":\"sensor\",\"id\":\"" + sensor.id() + "\"}";
    }
    @Override public String visit(WeatherStation station) {
        return "{\"type\":\"weather-station\",\"id\":\"" + station.id() + "\"}";
    }
    @Override public String visit(Drone drone) {
        return "{\"type\":\"drone\",\"id\":\"" + drone.id() + "\"}";
    }

    private String join(java.util.List<FarmElement> children) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < children.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(children.get(i).accept(this));
        }
        return sb.toString();
    }
}