package com.farmpulse.visitor;

import com.farmpulse.tree.*;

public interface Visitor<R> {
    R visit(Farm farm);
    R visit(Field field);
    R visit(Crop crop);
    R visit(Pump pump);
    R visit(Sensor sensor);
    R visit(WeatherStation station);
    R visit(Drone drone);
}