package com.farmpulse.visitor;

import com.farmpulse.tree.*;

public final class PumpMaintenanceCostVisitor implements Visitor<Double> {
    @Override public Double visit(Farm farm) { return sum(farm); }
    @Override public Double visit(Field field) { return sum(field); }

    // Стоимость обслуживания насоса - например, 10 рублей за 1 литр/час
    @Override public Double visit(Pump pump) { return pump.flowRateLitersPerHour() * 10.0; }
    @Override public Double visit(Drone drone) { return 0.0; }
    @Override public Double visit(Crop crop) { return 0.0; }
    @Override public Double visit(Sensor sensor) { return 0.0; }
    @Override public Double visit(WeatherStation station) { return 0.0; }

    private Double sum(CompositeElement element) {
        double total = 0.0;
        for (FarmElement child : element.children()) {
            total += child.accept(this);
        }
        return total;
    }
}