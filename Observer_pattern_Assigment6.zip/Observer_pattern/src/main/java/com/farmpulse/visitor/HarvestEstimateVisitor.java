package com.farmpulse.visitor;

import com.farmpulse.tree.*;

public final class HarvestEstimateVisitor implements Visitor<Double> {

    @Override public Double visit(Farm farm) { return sum(farm); }
    @Override public Double visit(Field field) { return sum(field); }

    @Override public Double visit(Crop crop) { return crop.expectedYieldKg(); }
    @Override public Double visit(Pump pump) { return 0.0; }
    @Override public Double visit(Sensor sensor) { return 0.0; }
    @Override public Double visit(WeatherStation station) { return 0.0; }
    @Override public Double visit(Drone drone) { return 0.0; }

    private Double sum(CompositeElement element) {
        double total = 0.0;
        for (FarmElement child : element.children()) {
            total += child.accept(this);
        }
        return total;
    }
}