package com.farmpulse.visitor;

import com.farmpulse.tree.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class VisitorTest {

    @Test
    void waterUsageMatchesHandCalculatedValue() {
        // Собираем дерево вручную
        Crop wheat = new Crop("wheat", 10.0, 100.0); // 10 литров воды
        Pump pump = new Pump("p1", 50.0);            // 50 литров расхода
        Field field = new Field("f1", "North", 10.0, List.of(wheat, pump));
        Farm farm = new Farm("farm1", "Farm", List.of(field));

        // Ручной расчет: 10 + 50 = 60
        double expected = 60.0;
        assertEquals(expected, farm.accept(new WaterUsageVisitor()));
    }

    @Test
    void harvestEstimateMatchesHandCalculatedValue() {
        Crop wheat = new Crop("wheat", 10.0, 150.0); // 150 кг урожая
        Crop corn = new Crop("corn", 20.0, 250.0);   // 250 кг урожая
        Field f1 = new Field("f1", "North", 10.0, List.of(wheat));
        Field f2 = new Field("f2", "South", 10.0, List.of(corn));
        Farm farm = new Farm("farm1", "Farm", List.of(f1, f2));

        // Ручной расчет: 150 + 250 = 400
        double expected = 400.0;
        assertEquals(expected, farm.accept(new HarvestEstimateVisitor()));
    }

    @Test
    void filterReturnsOnlyLowMoistureSensors() {
        Sensor low = new Sensor("s1", 30.0);  // Ниже порога 40
        Sensor high = new Sensor("s2", 50.0); // Выше порога 40
        Field field = new Field("f1", "North", 10.0, List.of(low, high));
        Farm farm = new Farm("farm1", "Farm", List.of(field));

        List<Sensor> result = farm.accept(new LowMoistureSensorFilterVisitor(40.0));

        assertEquals(1, result.size(), "Должен найтись только 1 датчик");
        assertEquals("s1", result.get(0).id());
    }

    @Test
    void jsonExportContainsCorrectNesting() {
        Crop wheat = new Crop("wheat", 10.0, 100.0);
        Field field = new Field("f1", "North", 10.0, List.of(wheat));
        Farm farm = new Farm("farm1", "Farm", List.of(field));

        String json = farm.accept(new JsonExportVisitor());

        assertTrue(json.contains("\"farm\":\"Farm\""));
        assertTrue(json.contains("\"fields\":[{\"field\":\"North\""));
        assertTrue(json.contains("\"type\":\"crop\""));
    }
}