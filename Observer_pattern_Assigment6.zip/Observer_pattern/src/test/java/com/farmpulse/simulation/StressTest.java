package com.farmpulse.simulation;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import com.farmpulse.observer.EventBusSubject;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StressTest {

    @Test
    void fourThreadsOneThousandEventsEachAreAllDelivered() throws InterruptedException {
        EventBusSubject<FarmEvent> bus = new EventBusSubject<>();
        AtomicInteger delivered = new AtomicInteger();

        bus.subscribe(EventType.SOIL_MOISTURE_READING, e -> delivered.incrementAndGet());

        ExecutorService pool = Executors.newFixedThreadPool(4);
        int perThread = 1000;

        // 4 потока по 1000 событий = 4000
        for (int t = 0; t < 4; t++) {
            pool.submit(() -> {
                for (int i = 0; i < perThread; i++) {
                    bus.publish(new FarmEvent(EventType.SOIL_MOISTURE_READING, "s", Instant.now(), Map.of()));
                }
            });
        }

        pool.shutdown();
        assertTrue(pool.awaitTermination(10, TimeUnit.SECONDS), "Потоки не завершились вовремя");

        // Проверяем, что ни одно событие не потерялось
        assertEquals(4000, delivered.get(), "Должно быть доставлено ровно 4000 событий");
    }
}