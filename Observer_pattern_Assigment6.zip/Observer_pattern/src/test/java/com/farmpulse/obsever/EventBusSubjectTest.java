package com.farmpulse.observer;

import com.farmpulse.event.EventType;
import com.farmpulse.event.FarmEvent;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EventBusSubjectTest {

    private FarmEvent createEvent(EventType type) {
        return new FarmEvent(type, "test-source", Instant.now(), Map.of());
    }

    @Test
    void listenerReceivesPublishedEvent() {
        EventBusSubject<FarmEvent> bus = new EventBusSubject<>();
        List<FarmEvent> received = new ArrayList<>();

        // Подписываемся
        bus.subscribe(EventType.SOIL_MOISTURE_READING, received::add);

        // Публикуем
        bus.publish(createEvent(EventType.SOIL_MOISTURE_READING));

        assertEquals(1, received.size(), "Слушатель должен получить 1 событие");
    }

    @Test
    void listenerOnlyReceivesItsEventType() {
        EventBusSubject<FarmEvent> bus = new EventBusSubject<>();
        List<FarmEvent> received = new ArrayList<>();

        bus.subscribe(EventType.FROST_WARNING, received::add); // подписан только на мороз

        bus.publish(createEvent(EventType.SOIL_MOISTURE_READING)); // публикуем влажность
        bus.publish(createEvent(EventType.FROST_WARNING));         // публикуем мороз

        assertEquals(1, received.size(), "Должно прийти только событие FROST_WARNING");
        assertEquals(EventType.FROST_WARNING, received.get(0).type());
    }
}