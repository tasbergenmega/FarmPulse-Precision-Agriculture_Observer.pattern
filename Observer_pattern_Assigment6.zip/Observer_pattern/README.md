# FarmPulse: Precision Agriculture (Variant 9)

This project implements the **Observer** and **Visitor** design patterns for a Precision Agriculture monitoring system, fulfilling all assignment requirements (Clean Code, Concurrency, Integration).

## Build & Run

* **Run tests:** `mvn test`
* **Run simulation:** Execute the `main` method in `com.farmpulse.app.FarmApplication`.

---

## Design Decisions

### 1. Observer: Push vs Pull
**Decision:** We use the **Push** model.
**Justification:** The `Subject` pushes an immutable `FarmEvent` object to the listeners. This reduces coupling because listeners do not need to hold a reference to the subject to query its state. Since the events are immutable (`record` with `Map.copyOf`), they can be safely passed across threads without synchronization issues.

### 2. Visitor: Traversal Responsibility
**Decision:** The **Visitor** performs the traversal.
**Justification:** Element classes (`Farm`, `Field`, `Crop`, etc.) are kept as pure data structures (no business logic). By putting the traversal logic inside the `Visitor` (e.g., `WaterUsageVisitor` iterating over `element.children()`), we allow different visitors to implement different traversal strategies (e.g., a filter visitor might not need to traverse the whole tree, or an accumulator might process nodes differently). This keeps the tree stable and respects the Open/Closed Principle.

### 3. Concurrency & Thread Safety
* We use `ConcurrentHashMap` to store listeners by `EventType`, ensuring that subscribing/unsubscribing does not lock the whole subject.
* We wrap listener lists in `CopyOnWriteArrayList`. This ensures that a listener can safely **unsubscribe from within its own `onEvent` handler** without causing a `ConcurrentModificationException`, as the iteration happens over a snapshot.
* **Graceful shutdown:** The `FarmSimulation` uses an `ExecutorService` with a configurable thread pool. It calls `shutdown()` followed by `awaitTermination()` to ensure no events are lost and no hanging threads remain.

---

## Trade-off Proof (Open/Closed Principle)

The assignment requires proving the cost of extending the system in two different directions. This is documented via two separate commits.

### Commit A: Adding a New Visitor (No element changes)
* **Goal:** Add a `PumpMaintenanceCostVisitor` to calculate pump maintenance costs.
* **Files Changed:**
    * `PumpMaintenanceCostVisitor.java` (NEW)
    * `FarmApplication.java` (Wiring only)
* **Cost:** **Low.** We did not touch any element classes (`Farm`, `Field`, `Pump`, etc.). This proves the system is Open for extension via Visitors.

### Commit B: Adding a New Element Type
* **Goal:** Add a `Drone` element (a new leaf type) to the tree.
* **Files Changed:**
    * `Drone.java` (NEW)
    * `Visitor.java` (Added `visit(Drone)` method)
    * `WaterUsageVisitor.java`, `HarvestEstimateVisitor.java`, `LowMoistureSensorFilterVisitor.java`, `JsonExportVisitor.java` (All implementations updated).
* **Cost:** **High.** Adding a new element forces us to modify the `Visitor` interface and *every* existing visitor implementation. This is the classic trade-off of the Visitor pattern. However, this guarantees type safety and double-dispatch at compile time.

---

## UML Class Diagram

```mermaid
classDiagram
    %% OBSERVER PATTERN
    class Subject~E~ {
        <<interface>>
        +subscribe(EventType, Observer~E~)
        +unsubscribe(EventType, Observer~E~)
        +publish(E)
    }
    class Observer~E~ {
        <<interface>>
        +onEvent(E)
    }
    class EventBusSubject~E~ {
        -Map~EventType, List~Observer~~ listeners
    }
    class SoilSensorSource
    class WeatherSensorSource
    class StatisticsAggregator
    
    Subject <|.. EventBusSubject
    EventBusSubject <|-- SoilSensorSource
    EventBusSubject <|-- WeatherSensorSource
    Observer <|.. StatisticsAggregator
    Subject <|.. StatisticsAggregator : delegates
    Observer <|.. IrrigationController
    Observer <|.. DashboardListener
    Observer <|.. FrostAlertListener

    %% VISITOR PATTERN
    class FarmElement {
        <<interface>>
        +accept(Visitor~R~)
    }
    class CompositeElement {
        <<interface>>
        +children() List~FarmElement~
    }
    class Visitor~R~ {
        <<interface>>
        +visit(Farm)
        +visit(Field)
        +visit(Crop)
        +visit(Pump)
    }
    class Farm
    class Field
    class Crop
    class Pump

    FarmElement <|.. CompositeElement
    FarmElement <|.. Crop
    FarmElement <|.. Pump
    CompositeElement <|.. Farm
    CompositeElement <|.. Field
    Visitor <|.. WaterUsageVisitor
    Visitor <|.. JsonExportVisitor